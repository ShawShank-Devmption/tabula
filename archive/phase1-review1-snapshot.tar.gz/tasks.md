# Task Plan — Phase-Wise Implementation

**Project:** Tabula — Spreadsheet Engine with Compiled Formulas, Dependency Graph & Incremental Recomputation
Phases mirror the course structure: **Phase 1** Problem Definition & Design (Review 1, 20 marks) · **Phase 2** Core Implementation (Review 2, 25 marks) · **Phase 3** Final Implementation & Testing (Review 3, 35 marks).

Conventions: tasks ordered by dependency; each lists its **Done-when** criterion. Check off (`[x]`) as completed. Commit after every task (manual §22–23).

---

## Phase 1 — Problem Definition, Design, and Prototype

**Goal for Review 1:** approved topic, complete design documents, formula-language specification, and a working prototype (formula lexer + parser + direct evaluation on a basic grid).

### 1.1 Project Setup
- [ ] **T1.1** Initialize Git repository; create folder skeleton from `design.md` §1.2 (`tabula/`, `tests/`, `examples/`); `README.md` stub, `.gitignore`, pytest config.
  *Done when:* `pytest` runs (0 tests) and the tree matches the design layout.
- [ ] **T1.2** Prepare the **project proposal** for faculty approval from `requirements.md` §1–§6 (title, problem statement, motivation, objectives, scope, concepts, methodology, architecture, tech stack, expected outcomes).
  *Done when:* proposal submitted / approved.

### 1.2 Language Specification (freeze before coding)
- [ ] **T1.3** Finalize token table, grammar, precedence tiers, the ~20-function library table (name, arity, param kinds, semantics), coercion rules, and error-value semantics (design.md §2.2–§4.1). Write 5 sample sheets in `examples/` (e.g. `budget.tsv`, `grades.tsv`) exercising every operator and function.
  *Done when:* every sample formula hand-checked against the grammar; function table complete.
- [ ] **T1.4** Paper-walk 3 tricky formulas through the grammar (mixed precedence with `^` right-assoc, `&` vs comparison, nested calls with ranges) and record derivations in `docs/derivations.md`.
  *Done when:* derivations documented (Review-1 background-study evidence).

### 1.3 Core Infrastructure
- [ ] **T1.5** Implement `refs.py` (CellRef/RangeRef parse+format incl. `$` forms, bounds A–ZZ/1–10000), `values.py` (Value model + ErrorValue + propagation helper), `diagnostics.py` (positioned diagnostics, caret rendering).
  *Done when:* round-trip and propagation unit tests pass.

### 1.4 Prototype (Review-1 demo)
- [ ] **T1.6** Implement the **formula lexer**: all token types incl. references, ranges, `""` string escapes, `<>`/`<=`/`>=` maximal munch; all lexical error kinds with skip-and-continue.
  *Done when:* `tests/test_lexer.py` passes (every token type + every error + position assertions).
- [ ] **T1.7** Implement the **Pratt parser** for the full expression grammar → AST.
  *Done when:* table-driven precedence/associativity tests pass (`=2+3*4`, `=2^3^2` = 512, `="a"&1+2`, `=-A1^2`, nested calls).
- [ ] **T1.8** Implement a **prototype direct AST evaluator** (numbers, arithmetic, comparisons, cell refs, `SUM`/`IF` only) over a minimal in-memory grid with a bare `set`/`get`/`show` REPL. Throwaway evaluation path — replaced by the VM in Phase 3.
  *Done when:* demo script works: set literals, set `=SUM(A1:A3)*2`, edit an input, `show` reflects it (full recompute for now).
- [ ] **T1.9** Implement `explain <cell>` v0: token table + AST tree dump.
  *Done when:* readable output for any example formula.

### 1.5 Review 1 Preparation
- [ ] **T1.10** Assemble Review-1 pack: proposal + `requirements.md` + `design.md` + demo script (live formula editing, `explain` dumps, one lexical and one syntax error shown with carets).
  *Done when:* one full dry run done; viva-ready on: DFA scanning, Pratt precedence, why errors-as-values, why hand-written over Lex/Yacc.

**Phase 1 exit criteria:** lexer + parser complete and tested · basic grid evaluating simple formulas live · both design docs final · proposal approved.

---

## Phase 2 — Core Implementation

**Goal for Review 2:** the full front end and the macro engine working — semantic analysis with symbol tables, dependency graph, cycle detection, correct (full) recomputation, all error values live in the grid. (Rubric: progress 7, correctness 5, concepts 4, code quality 3, testing 3, viva 3.)

### 2.1 Semantic Analysis & Symbol Tables
- [ ] **T2.1** Implement the **function registry** (`sema/functions.py`): `FunctionSpec` for all ~20 builtins with arity, param kinds, purity, error policy, and implementations.
  *Done when:* registry unit tests pass (spec lookup, arity ranges, kind declarations).
- [ ] **T2.2** Implement the **named-range table** (`sema/names.py`) + REPL `name`/`names` commands.
  *Done when:* declare/resolve/redefine tests pass; case-insensitivity verified.
- [ ] **T2.3** Implement the **checker** (`sema/checker.py`): name resolution order, arity/kind checks, static type checks on literal-typed subexpressions, bounds → `#REF!`, and **precedent-set extraction** (refs, ranges expanded, named ranges resolved, >50k-cell range cap).
  *Done when:* one positive + one negative test per rule passes; extraction tests incl. names and ranges pass.
- [ ] **T2.4** Route all sema failures to error values per design §9 (diagnostic printed at `set`, cell shows `#NAME?`/`#REF!`/`#VALUE!`, sheet unaffected).
  *Done when:* scenario test: 3 broken cells + 3 valid cells coexist correctly.

### 2.2 Dependency Graph & Recomputation
- [ ] **T2.5** Implement `engine/grid.py` (sparse grid, Cell model) and TSV `load`/`save`.
  *Done when:* round-trip invariant test `load(save(g)) == g` passes on all examples.
- [ ] **T2.6** Implement `engine/graph.py`: bidirectional edges with diff-based `update`, iterative **cycle detection** (coloring DFS), `dirty_closure`, and **Kahn topological ordering** restricted to the dirty subgraph.
  *Done when:* graph unit tests pass — edge diffing on re-edit, self-loop / 2-cycle / long cycle / cycle-through-range, closure correctness, topo validity on DAGs ≥ 5,000 deep (no recursion errors).
- [ ] **T2.7** Implement the **Edit Controller** (`engine/engine.py`) per design §6.3, with full-sheet recompute for now (`dirty = all formula cells`) still flowing through the same topo path; `#CYCLE!` marking with printed cycle path, and un-marking when an edit breaks a cycle.
  *Done when:* scenario tests pass: values correct after edit scripts; cycle appears and clears; extend the Phase-1 AST evaluator to the full function library en route.
- [ ] **T2.8** Extend the REPL: `deps <cell>`, `get`, `show <range>`, `:set formulas on`, batch mode `--run script.txt` with exit codes.
  *Done when:* commands work on example sheets; batch mode drives a scenario test.

### 2.3 Phase 2 Quality Gate & Review
- [ ] **T2.9** Grow the corpus: ≥ 12 valid sheets/scripts and ≥ 12 error cases covering every diagnostic and error value (lexical, syntax, each sema rule, cycles, runtime `#DIV/0!`/`#VALUE!`), wired into scenario tests with expected grids.
  *Done when:* corpus green in pytest.
- [ ] **T2.10** Write the **implementation progress report** (module-wise explanation, screenshots: `explain`, `deps`, cycle demo) per manual §10.3.
  *Done when:* report exported.
- [ ] **T2.11** Review-2 demo dry run: live editing on `budget.tsv`; `explain` a formula; create and break a cycle; show each error value once; rehearse viva (symbol tables, precedent extraction, DFS coloring, Kahn, error propagation).
  *Done when:* full dry run completed once without notes.

**Phase 2 exit criteria:** any valid formula compiles, checks, and evaluates with correct dependencies · cycles detected/cleared live · all error values demonstrable · unit + scenario tests green · progress report ready.

---

## Phase 3 — Optimization, Bytecode VM, Incrementality, Testing & Documentation

**Goal for Review 3:** the complete system — optimizer, bytecode VM replacing the prototype evaluator, true incremental recomputation with measured results, full `explain`/HTML report, comprehensive tests, final report, presentation. (Rubric: completion 6, correctness 6, complexity 5, concepts 4, testing 4, demo 4, viva 4, docs 2.)

### 3.1 Optimizer
- [ ] **T3.1** Implement AST passes (`opt/passes.py`): constant folding, algebraic simplification, IF/AND/OR branch elimination; fixpoint pass manager recording per-pass changes.
  *Done when:* per-pass before/after unit tests pass; fixpoint terminates on the whole corpus.
- [ ] **T3.2** Re-extract precedents **after** optimization so folded-away references leave the dependency graph (`=IF(FALSE,B1,7)` has no precedents).
  *Done when:* `deps` test proves the graph shrinks under optimization.
- [ ] **T3.3** Add `:set opt on|off` (recompiles all formulas) and the **value-equivalence invariant test**: entire corpus evaluates identically with opt on/off.
  *Done when:* invariant test green.

### 3.2 Bytecode & VM
- [ ] **T3.4** Implement `codegen/bytecode.py`: OpCode set, Chunk (code/consts/refs pools), AST→bytecode lowering with **jump-compiled short-circuit IF/AND/OR**, peephole pass, disassembler.
  *Done when:* golden bytecode tests per construct pass; disassembly readable.
- [ ] **T3.5** Implement `vm/vm.py`: stack evaluation, coercions, error-value propagation, `#DIV/0!`, instruction counting.
  *Done when:* VM unit tests pass for every function, every operator, every error value; short-circuit proven (error in untaken IF branch does not propagate).
- [ ] **T3.6** **Swap the VM in** for the prototype AST evaluator; delete the prototype path.
  *Done when:* entire Phase-2 test suite green on the VM with the old evaluator removed.

### 3.3 Incremental Recomputation & Stats
- [ ] **T3.7** Switch the Edit Controller to true incrementality: `dirty = closure({edited})`, topo over dirty subgraph only.
  *Done when:* scenario tests assert **exact recompute sets** per edit AND the invariant *incremental result ≡ full recompute* holds across the corpus.
- [ ] **T3.8** Implement `stats` (recomputed/total cells, Σ VM instructions, elapsed ms) and a benchmark **sheet generator** (chain, tree, wide-fanout, 10k mixed topologies).
  *Done when:* `stats` accurate on scenarios; generator produces all four topologies.

### 3.4 Visualizer & Integration
- [ ] **T3.9** Complete `explain`: tokens → AST → names/precedents → per-pass opt diff → disassembled bytecode → value + instruction count.
  *Done when:* full output renders for every corpus formula.
- [ ] **T3.10** Implement the **HTML report** (`report <file>.html`): rendered grid with highlighted errors, dependency adjacency table, per-formula-cell explain sections; self-contained file.
  *Done when:* report opens locally and renders fully for `budget.tsv` and a benchmark sheet.

### 3.5 System Testing & Performance Evaluation
- [ ] **T3.11** Complete the test matrix of design §10: boundary cases (empty sheet, blank refs, `ZZ10000`, max range, 5k-deep chains, named-range redefinition), complex sheets (≥ 3 realistic: budget with rollups, gradebook with conditionals, loan schedule); FR checklist sweep against requirements §7.
  *Done when:* full pytest suite green; every FR ticked.
- [ ] **T3.12** **Performance evaluation:** benchmark table — incremental vs full recompute (cells recomputed, wall time) per topology; optimizer effect (bytecode length, instructions executed, graph edges removed); verify NFR-2 (10k sheet, <100 ms bounded edit).
  *Done when:* results table produced and interpreted in the report.
- [ ] **T3.13** Capture output evidence: terminal captures of every REPL command, every error value, cycle path demo, `explain`, `stats` on the 10k sheet, HTML report screenshots (manual §12.3).
  *Done when:* evidence folder complete.

### 3.6 Documentation & Review 3
- [ ] **T3.14** Write the **final project report** per manual §24 chapter structure (Introduction → Future Enhancements, References, Appendix), reusing requirements.md/design.md, adding testing and benchmark results.
  *Done when:* report complete and formatted.
- [ ] **T3.15** Write **user instructions** in `README.md`: install, REPL tour, all commands, formula-language reference with examples.
  *Done when:* a fresh clone + README alone reproduces every demo.
- [ ] **T3.16** Prepare the **presentation** and rehearse the Review-3 demo: edit → watch minimal recompute → `stats` on 10k sheet → cycle creation/repair → `explain` with opt diff → HTML report. Viva prep sheet covering every module's algorithm (Pratt, DFS coloring, Kahn, folding, peephole, error propagation).
  *Done when:* timed dry run ≤ allotted slot.
- [ ] **T3.17** Final housekeeping: docstring/comment pass, naming consistency, dead-code removal, tag `v1.0`.
  *Done when:* repo clean; `pytest` green on the tag.

**Phase 3 exit criteria:** every FR/NFR satisfied · full suite green incl. equivalence invariants · measured incremental + optimization results · final report, README, presentation, evidence pack complete.

---

## Dependency Overview

```
T1.5 ─► T1.6 ─► T1.7 ─► T1.8 ─► T1.9              (Phase 1)
T1.7 ─► T2.1/T2.2 ─► T2.3 ─► T2.4
T1.8 ─► T2.5 ─► T2.6 ─► T2.7 ─► T2.8 ─► T2.9      (Phase 2)
T2.3 ─► T3.1 ─► T3.2 ─► T3.3
T2.7 ─► T3.4 ─► T3.5 ─► T3.6 ─► T3.7 ─► T3.8      (Phase 3)
T3.1 + T3.6 ─► T3.9 ─► T3.10 ─► T3.11 ─► T3.12…T3.17
```

## Risk Register

| Risk | Impact | Mitigation |
|---|---|---|
| Incremental engine returns stale/wrong values | Correctness failure at the project's core | Invariant tests from day one: incremental ≡ full recompute on every scenario; single shared topo/eval code path (design §6.3) |
| Optimizer changes results | Wrong outputs, subtle | T3.3 corpus-wide opt-on/off equivalence test; folding restricted to pure functions |
| Deep chains hit Python recursion limits | Crashes on benchmarks | Iterative DFS/Kahn only (design §11); 5k-depth test in T2.6 |
| Range-heavy sheets blow up the graph | Performance failure | Range expansion cap (§5.3); wide-fanout benchmark topology exercises it |
| Prototype evaluator lingers into Phase 3 | Two semantics drift apart | T3.6 explicitly deletes it; suite must pass on VM alone |
| Scope creep (GUI, dates, volatile fns) | Missed deadlines | Out-of-scope list in requirements §5 is contractual; ideas → Future Enhancements |
| Review viva depth | Marks loss | Per-phase viva prep (T1.10, T2.11, T3.16); no unexplained code merged |
