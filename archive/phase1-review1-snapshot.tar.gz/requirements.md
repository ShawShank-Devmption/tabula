# Requirements Document

**Project Title:** Tabula — A Spreadsheet Engine with a Compiled Formula Language, Dependency-Graph Analysis, and Incremental Recomputation

**Course:** BCSE307P — Compiler Design Laboratory
**Project Type:** Individual
**Semester:** Fall 2026–27

---

## 1. Project Overview

Tabula is a spreadsheet engine built from scratch in which **every cell formula is a program** that passes through a complete compiler pipeline. It consists of:

1. **A formula language** (`=SUM(A1:B4) * rate + IF(C2 > 0, "profit", "loss")`) with numbers, strings, booleans, cell references, ranges, named ranges, operators, and a library of built-in functions.
2. **A per-formula compiler** — lexer, parser, semantic analyzer (function/arity/type checking, name resolution via symbol tables), optimizer, and bytecode generator.
3. **A stack-based evaluation VM** that executes compiled formulas with spreadsheet error-value semantics (`#DIV/0!`, `#VALUE!`, `#REF!`, `#NAME?`, `#CYCLE!`).
4. **A dependency-graph engine** — the innovation core — that extracts cell dependencies during compilation, detects circular references, and performs **incremental recomputation**: when one cell changes, only its transitive dependents are re-evaluated, in topological order.
5. **An interactive CLI/REPL** with an `explain` command that exposes the full compilation pipeline of any cell (tokens → AST → dependencies → optimized bytecode → cached value), plus an HTML report generator.

Every component is hand-written in Python (no Lex/Yacc/ANTLR, no spreadsheet or expression libraries), so the entire codebase can be explained line-by-line during viva.

---

## 2. Problem Statement

Spreadsheets are the world's most widely used programming environment, yet the machinery that makes them work is invisible: every formula must be parsed, checked, compiled, and — critically — re-evaluated *efficiently* when any cell it depends on changes. Naive engines recompute the entire sheet on every edit, which scales as O(all cells); real engines maintain a dependency graph and recompute only what changed.

**The problem:** implementing this machinery is a genuinely compiler-shaped task — a language front end, static analysis over a graph of interdependent programs, and an execution engine with incremental semantics — but no compact, transparent, single-student implementation exists that exposes how it works.

This project builds that system: a complete formula compiler per cell, plus the cross-cell static analysis (dependency extraction, cycle detection, topological scheduling) that turns thousands of tiny programs into one consistent, efficiently updatable spreadsheet.

---

## 3. Motivation

- Spreadsheet recalculation is one of the few places where classical compiler techniques (parsing, symbol resolution, IR, optimization) meet **incremental computation** — a topic ordinary course projects never reach.
- The system is two compilers deep: a *micro* pipeline per formula, and a *macro* static analysis across the sheet (the dependency graph is a program-analysis artifact, cycle detection is a semantic check, topological recomputation is a scheduling problem).
- Everyone understands the demo instantly: edit a cell, watch exactly the right cells update — then show `#CYCLE!` appear when you create a circular reference.
- The optimization story is **measurable**, satisfying the Phase 3 performance-evaluation requirement: "editing 1 cell in a 10,000-cell sheet recomputed 14 cells, not 10,000" and "constant folding reduced bytecode length by N%".

---

## 4. Objectives

1. Design the Tabula formula language: token set, grammar (EBNF), type/coercion rules, error-value semantics, and built-in function library (≈ 20 functions).
2. Implement a hand-written **lexer** for formulas: cell references (`A1`, `$B$2`), range literals (`A1:B4`), numbers, strings, booleans, operators, function names — with position-tracked lexical error reporting.
3. Implement a **recursive-descent / Pratt parser** producing a formula AST, reporting syntax errors with caret-annotated positions.
4. Implement **semantic analysis**: a function-registry and named-range **symbol table**, unknown-name detection (`#NAME?`), arity checking, static type checking where types are decidable, and reference validation (`#REF!` for out-of-bounds references).
5. Extract **cell dependencies** from each compiled formula; maintain the sheet-level **dependency graph**; detect **circular references** and mark all cells in a cycle with `#CYCLE!`.
6. Implement **optimization**: constant folding, algebraic simplification, constant-condition `IF`/`AND`/`OR` elimination at the AST level, plus a bytecode peephole pass — each toggleable and individually measurable.
7. Compile formulas to **stack-machine bytecode** and implement the **evaluation VM** with spreadsheet error propagation and runtime error detection.
8. Implement **incremental recomputation**: dirty-set propagation over the dependency graph and re-evaluation in topological order, with recompute statistics.
9. Build the **REPL/CLI** (`set`, `show`, `explain`, `deps`, `stats`, load/save) and a single-file **HTML report** of the sheet plus any cell's full pipeline.
10. Validate with a comprehensive test suite: valid formulas, all error categories, boundary cases, cycle scenarios, and incremental-recomputation benchmarks on generated large sheets.

---

## 5. Scope

### In scope

| Area | Contents |
|---|---|
| Formula language | Number/string/boolean literals; cell refs (relative `A1`, absolute `$A$1`); ranges `A1:B4`; named ranges; operators `+ - * / % ^` (arith), `&` (concat), `= <> < <= > >=` (comparison), unary `-`; function calls; parentheses |
| Built-in functions | `SUM AVG MIN MAX COUNT COUNTIF ROUND ABS SQRT MOD POWER IF AND OR NOT LEN CONCAT UPPER LOWER TRIM ISNUMBER ISBLANK` |
| Compiler | Lexer, parser + AST, semantic analyzer + symbol tables, AST optimizer, bytecode generator + peephole |
| Engine | Sparse grid, dependency graph, cycle detection, full + incremental recomputation, error-value propagation |
| Runtime | Stack VM, all five error values, runtime error localization |
| Tooling | REPL/CLI, per-cell `explain` pipeline dump, dependency queries (precedents/dependents), recompute stats, TSV-based load/save, HTML report |
| Quality | pytest suite; sample sheet corpus incl. generated benchmark sheets; user instructions |

### Out of scope (documented as future enhancements)

- GUI (the CLI grid renderer + HTML report are the interfaces); no curses/web frontend required
- Volatile functions (`NOW()`, `RAND()`), date/time types
- Cross-sheet references, insert/delete row-column with reference rewriting
- Array/spill formulas, lambdas/user-defined functions in the formula language
- Charting, formatting, undo/redo, concurrent editing

---

## 6. Proposed Solution

Two cooperating layers:

**Micro pipeline (per formula), run whenever a cell's formula is set:**

```
"=SUM(A1:B4)*rate"
   │
   ▼
[1] Lexer ──► tokens                       (explain: tokens)
   ▼
[2] Parser ──► AST                         (explain: ast)
   ▼
[3] Semantic Analyzer ──► checked AST      (explain: types, names)
   │        + reference set {A1..B4, rate}
   ▼
[4] AST Optimizer ──► simplified AST       (explain: opt diff)
   ▼
[5] Bytecode Generator + peephole ──► Chunk (explain: bytecode)
```

**Macro engine (per sheet), run on every cell edit:**

```
set C1 = <formula>
   ├─► compile (micro pipeline) ──► Chunk + reference set
   ├─► update dependency graph edges for C1
   ├─► cycle check (DFS from C1) ──► mark #CYCLE! if found
   ├─► dirty set = {C1} ∪ transitive dependents of C1
   └─► recompute dirty set in topological order on the VM
        └─► stats: |dirty| vs |all cells|, eval time
```

**Innovation / originality claims:**

1. **Incremental recomputation as the headline feature** — dependency-graph-driven minimal re-evaluation, with live statistics proving it (recomputed-cell counts, timing vs. full recompute).
2. **Cycle detection as a first-class semantic diagnostic** — `#CYCLE!` with the actual cycle path printed (`C1 → D2 → C1`).
3. **`explain <cell>`** — a per-cell compiler X-ray showing every stage's artifact, unified in an HTML report.
4. **Spreadsheet error-value semantics** implemented faithfully (errors are typed values that propagate through expressions, as in real engines) — a semantics topic beyond typical course projects.
5. Fully hand-written front end (no parser generators, no `eval`).

---

## 7. Functional Requirements

| ID | Requirement |
|----|-------------|
| FR-1 | The system shall maintain a sparse grid of cells addressable as `A1`-style references, holding literals (number, string, boolean) or formulas (text beginning with `=`). |
| FR-2 | The lexer shall tokenize formulas — including cell references, absolute references, ranges, numbers, strings with escapes, booleans, operators, and identifiers — attaching column positions, and shall report lexical errors (illegal character, unterminated string, malformed number/reference) without crashing. |
| FR-3 | The parser shall validate formulas against the Tabula grammar and build an AST, reporting syntax errors with position and caret excerpt. |
| FR-4 | The semantic analyzer shall resolve function names and named ranges through a symbol table, and reject: unknown functions/names (`#NAME?`), wrong argument counts, range arguments passed to scalar-only parameters, and statically detectable type mismatches. |
| FR-5 | The compiler shall extract the complete set of cell/range references (precedents) from every formula. |
| FR-6 | The engine shall maintain a bidirectional dependency graph (precedents/dependents) updated on every edit. |
| FR-7 | The engine shall detect circular references on edit, mark every cell in the cycle `#CYCLE!`, and report the cycle path. |
| FR-8 | The optimizer shall perform constant folding, algebraic simplification (`x*1`, `x+0`, `x^1`, …), and constant-condition elimination for `IF`/`AND`/`OR`, plus a bytecode peephole pass; optimization shall be toggleable (`:set opt off`) and its effect reportable. |
| FR-9 | The compiler shall generate stack-machine bytecode per formula; the VM shall evaluate chunks against the grid. |
| FR-10 | Evaluation shall implement spreadsheet error values — `#DIV/0!`, `#VALUE!`, `#REF!`, `#NAME?`, `#CYCLE!` — with propagation: any operand error becomes the result (aggregates like `COUNT`/`ISNUMBER` handle errors per their spec). |
| FR-11 | On any cell edit, the engine shall recompute **only** the edited cell and its transitive dependents, in topological order (incremental recomputation). |
| FR-12 | The REPL shall support: `set <cell> <value|formula>`, `show` (grid render), `get <cell>`, `explain <cell>` (tokens, AST, references, optimization diff, bytecode, value), `deps <cell>` (precedents + dependents), `names` (named ranges), `name <id> <range>`, `stats`, `load <file>`, `save <file>`, `report <file>.html`. |
| FR-13 | `stats` shall report, for the last edit: cells recomputed vs. total formula cells, evaluation time, and bytecode instructions executed. |
| FR-14 | The system shall load and save sheets in a plain-text TSV format preserving formulas. |
| FR-15 | All diagnostics shall identify the cell, position within the formula, error category, and a human-readable message; the process shall never crash on malformed input. |

## 8. Non-Functional Requirements

| ID | Requirement |
|----|-------------|
| NFR-1 | **Portability:** pure Python ≥ 3.11, standard library only (pytest as dev-only dependency); macOS/Linux/Windows. |
| NFR-2 | **Performance:** on a generated 10,000-formula sheet, a single-cell edit with a bounded dependent set shall recompute in under 100 ms; full initial computation under 5 s. |
| NFR-3 | **Modularity:** micro pipeline stages and macro engine are separate packages communicating only through defined data structures (tokens, AST, Chunk, graph). |
| NFR-4 | **Testability:** every stage unit-testable in isolation; engine behavior covered by scenario tests (edit scripts with expected recompute sets). |
| NFR-5 | **Code quality:** meaningful naming, docstrings on public interfaces, comments on non-obvious algorithms (manual §17, §22). |
| NFR-6 | **Robustness:** no unhandled Python exception escapes to the user for any input; everything surfaces as a diagnostic or error value. |

## 9. Input / Output Requirements

- **Input:** interactive REPL commands; sheet files (TSV with `=`-prefixed formulas); benchmark generator parameters.
- **Output:** rendered grid and cell values on stdout; diagnostics on stderr; `explain` artifacts; HTML report file; TSV save files.

---

## 10. Compiler Design Concepts Involved

| Course Concept | Where it appears in Tabula |
|---|---|
| Lexical analysis, token classification | Formula scanner: references, ranges, literals, operators (`lexer/`) |
| Context-free grammars, EBNF | Formula grammar (design.md §4) |
| Top-down parsing, operator precedence | Recursive descent + Pratt parser (`parser/`) |
| Error detection & recovery | Positioned lexical/syntax diagnostics; per-cell error containment (a bad formula yields an error value, never corrupts the sheet) |
| Abstract syntax trees | Formula AST + visitor-based passes |
| Symbol table management | Function registry + named-range table; cell namespace resolution |
| Semantic analysis | Name/arity/type checking; range-vs-scalar argument validation; **cycle detection as a whole-program semantic check** |
| Dependency / dataflow analysis | Precedent extraction, bidirectional dependency graph, transitive dirty-set closure |
| Intermediate representation | Stack-machine bytecode per formula (course-permitted "other IR"), with an explicit AST→IR lowering step |
| Code optimization | AST constant folding, algebraic simplification, branch elimination; bytecode peephole; **incremental recomputation as computation-level optimization** |
| Target code generation | AST → bytecode chunk with constant pool |
| Interpretation & runtime environments | Stack VM, grid as the store, error-value runtime semantics |
| Scheduling / topological ordering | Kahn's algorithm over the dirty subgraph for recomputation order |

## 11. Tools and Technologies

| Category | Choice | Justification |
|---|---|---|
| Language | Python 3.11+ | Recommended by manual (§20); concise for graph + tree heavy code |
| Parser approach | Hand-written (no Flex/Bison/ANTLR) | Full concept visibility for viva; positioned error messages |
| Testing | pytest | Unit + scenario + benchmark tests |
| Version control | Git (+ GitHub private repo) | Manual §23; commit history as development log |
| Editor | VS Code | Manual §21 |

## 12. Deliverables Mapped to Course Phases

| Phase | Course Deliverable (manual §8/§10/§12) | Produced Artifact |
|---|---|---|
| Phase 1 | Title, abstract, problem statement, motivation, objectives, scope, background, concepts, methodology, architecture, tech stack | `requirements.md` + `design.md` |
| Phase 1 | Language specification | `design.md` §3–§4 (tokens, grammar, types, error values, function library) |
| Phase 1 | Initial prototype | Formula lexer + parser + direct AST evaluator on a basic grid (see `tasks.md` Phase 1) |
| Phase 2 | Core modules, working code, demo, test cases, module explanation, progress report | Full parser, semantic analysis, symbol tables, dependency graph + cycle detection, full recompute, REPL core |
| Phase 3 | Complete project, full tests, screenshots, report, presentation, user instructions | Bytecode compiler + VM, optimizer, incremental recomputation + stats, `explain`/HTML report, benchmarks, final report, README |

## 13. Expected Outcomes

1. A working spreadsheet engine that correctly evaluates the full function library and error semantics on the test corpus.
2. Demonstrable detection of all error categories, including live circular-reference detection with cycle paths.
3. Measured results: incremental vs. full recomputation on benchmark sheets (cells recomputed, wall time), and static bytecode reduction from optimization.
4. Complete documentation per the manual's report format (§24).
5. Full individual command of every module for the three review vivas.

## 14. Constraints and Assumptions

- Individual work; all code authored by the student. AI tools per manual §19 (learning/debugging/documentation) with everything explainable and modifiable by the student.
- No expression-evaluation shortcuts: Python `eval` is prohibited by design; all evaluation goes through the compiled bytecode VM.
- Grid bounds: columns `A`–`ZZ`, rows 1–10,000 (references outside bounds ⇒ `#REF!`).
- Number semantics: Python floats with integer display when exact; documented as language semantics.
- Review dates follow the course schedule; `tasks.md` buffers each phase to finish before its review.
