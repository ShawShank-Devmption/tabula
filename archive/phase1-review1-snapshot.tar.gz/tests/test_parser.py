"""Parser tests: AST shape, precedence, associativity (task T1.7)."""
import pytest

from tabula.parser import (Binary, Bool, Call, Number, ParseError, RangeNode,
                           Ref, Text, Unary, parse_formula)


def shape(node):
    """Fully parenthesized rendering, so precedence is directly assertable."""
    if isinstance(node, Number):
        whole = node.value == int(node.value)
        return str(int(node.value)) if whole else str(node.value)
    if isinstance(node, Text):
        return f'"{node.value}"'
    if isinstance(node, Bool):
        return "TRUE" if node.value else "FALSE"
    if isinstance(node, Ref):
        return str(node.ref)
    if isinstance(node, RangeNode):
        return str(node.rng)
    if isinstance(node, Unary):
        return f"(-{shape(node.operand)})"
    if isinstance(node, Binary):
        return f"({shape(node.left)} {node.op} {shape(node.right)})"
    if isinstance(node, Call):
        return f"{node.fname}({', '.join(shape(a) for a in node.args)})"
    return repr(node)


@pytest.mark.parametrize("src,expected", [
    ("2+3*4",        "(2 + (3 * 4))"),          # * binds tighter than +
    ("2*3+4",        "((2 * 3) + 4)"),
    ("1+2-3",        "((1 + 2) - 3)"),          # left-associative
    ("2^3^2",        "(2 ^ (3 ^ 2))"),          # ^ is RIGHT-associative
    ("-A1^2",        "((-A1) ^ 2)"),            # unary binds tighter than ^
    ('"a"&1+2',      '("a" & (1 + 2))'),        # & is looser than +
    ("1+2<3*4",      "((1 + 2) < (3 * 4))"),    # comparison is loosest
    ("(2+3)*4",      "((2 + 3) * 4)"),
])
def test_precedence_and_associativity(src, expected):
    assert shape(parse_formula(src)) == expected


def test_range_and_call():
    assert shape(parse_formula("SUM(A1:B4)")) == "SUM(A1:B4)"
    assert shape(parse_formula("IF(A1>0,1,2)")) == "IF((A1 > 0), 1, 2)"


def test_nested_calls():
    assert shape(parse_formula("MAX(SUM(A1:A3),AVG(B1:B3))")) == \
        "MAX(SUM(A1:A3), AVG(B1:B3))"


@pytest.mark.parametrize("bad,message,pos", [
    ("SUM(A1:A3",  "expected ')' after argument list", 9),
    ("2+",         "unexpected end of formula",        2),
    ("(1+2",       "expected ')'",                     4),
    ("1 2",        "unexpected",                       2),
])
def test_syntax_errors_report_message_and_position(bad, message, pos):
    with pytest.raises(ParseError) as exc:
        parse_formula(bad)
    assert message in exc.value.message
    assert exc.value.pos == pos
