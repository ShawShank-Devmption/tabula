# Design Document — Software Requirements Specification & Architecture

**Project:** Tabula — Spreadsheet Engine with a Compiled Formula Language, Dependency-Graph Analysis, and Incremental Recomputation

This document is the complete technical specification. `requirements.md` says *what* and *why*; this document says *how*.

---

## 1. System Architecture

### 1.1 Two-Layer Architecture

Tabula has a **micro** layer (a complete compiler pipeline applied to each formula) and a **macro** layer (whole-sheet static analysis and scheduling over the results).

```
                                MACRO LAYER (per sheet)
 ┌─────────────────────────────────────────────────────────────────────────┐
 │                                                                         │
 │   Grid (sparse cells) ◄────────► Dependency Graph (precedents ⇄        │
 │        │                          dependents, per cell)                 │
 │        │ set A1 =…                     │                                │
 │        ▼                               ▼                                │
 │   [Edit Controller] ──► cycle check (DFS) ──► dirty-set closure         │
 │        │                                       │                        │
 │        │ compile via micro layer               ▼                        │
 │        │                              topological schedule (Kahn)       │
 │        │                                       │                        │
 │        ▼                                       ▼                        │
 │     Chunk + reference set ─────────────► [Evaluation VM] ──► values     │
 │                                                                         │
 └─────────────────────────────────────────────────────────────────────────┘

                                MICRO LAYER (per formula)
   "=SUM(A1:B4)*rate"
        │
        ▼
   [Lexer] ──► tokens ──► [Parser] ──► AST ──► [Semantic Analyzer] ──►
        checked AST + reference set ──► [AST Optimizer] ──► simplified AST
        ──► [Bytecode Generator + Peephole] ──► Chunk (code, consts, refs)

   Every artifact tees into ──► [Explain / Visualizer] ──► REPL dumps, report.html
   Every stage reports into ──► [Diagnostics] ──► positioned errors / error values
```

```mermaid
flowchart TB
    subgraph MICRO [Micro: formula compiler]
        F["=SUM(A1:B4)*rate"] --> LEX[Lexer] --> PAR[Parser] --> SEM[Semantic Analyzer]
        SEM --> OPT[AST Optimizer] --> GEN[Bytecode Gen + Peephole] --> CHUNK[Chunk]
    end
    subgraph MACRO [Macro: sheet engine]
        EDIT[Edit Controller] --> MICRO
        CHUNK --> DEP[Dependency Graph Update]
        DEP --> CYC[Cycle Detection]
        CYC --> DIRTY[Dirty-Set Closure]
        DIRTY --> TOPO[Topological Schedule]
        TOPO --> VM[Evaluation VM] --> GRID[Grid Values]
    end
    MICRO -.artifacts.-> EXPL[explain / HTML report]
```

### 1.2 Module Decomposition

```
tabula/
├── cli.py                  # REPL: command parsing, dispatch, grid rendering
├── diagnostics.py          # Diagnostic (cell, pos, category, msg), caret rendering
├── refs.py                 # CellRef, RangeRef: parse/format A1, $A$1, A1:B4; bounds
├── values.py               # Value model: Number, Text, Boolean, Blank, ErrorValue
├── lexer/
│   ├── token.py            # TokenType enum, Token dataclass (type, lexeme, value, pos)
│   └── lexer.py            # hand-written formula scanner
├── parser/
│   ├── ast.py              # AST node dataclasses (all carry Span)
│   └── parser.py           # recursive descent + Pratt expressions
├── sema/
│   ├── functions.py        # FunctionSpec registry (name, arity, param kinds, impl)
│   ├── names.py            # NamedRangeTable (symbol table for user-defined names)
│   └── checker.py          # name/arity/type checks; reference-set extraction
├── opt/
│   └── passes.py           # AST passes: fold, simplify, branch-eliminate; pass manager
├── codegen/
│   └── bytecode.py         # OpCode, Instruction, Chunk; AST→bytecode; peephole
├── vm/
│   └── vm.py               # stack VM: evaluate(chunk, grid) → Value
├── engine/
│   ├── cell.py             # Cell: raw text, chunk, value, spans of precedents
│   ├── grid.py             # sparse dict {(col,row): Cell}; bounds; TSV load/save
│   ├── graph.py            # DependencyGraph: edges, cycle detection, dirty closure,
│   │                       #   topological ordering (Kahn)
│   └── engine.py           # Edit Controller: set/get, recompute orchestration, stats
├── viz/
│   ├── explain.py          # per-cell pipeline dumps (tokens/AST/refs/opt-diff/bytecode)
│   └── report.py           # single-file HTML report (grid + per-cell pipelines)
tests/
├── test_lexer.py … test_engine.py    # unit tests per module
├── test_scenarios.py                  # edit-script scenario tests (expected recompute sets)
├── test_bench.py                      # generated large-sheet benchmarks
└── sheets/                            # corpus: valid/, errors/, cycles/, bench-generator
examples/                              # showcase sheets for demos (budget.tsv, grades.tsv)
```

**Dependency rule:** micro-layer packages depend only on earlier stages plus `refs`/`values`/`diagnostics`. `engine/` depends on the micro layer as a black box (`compile_formula(text) → Chunk | Diagnostic`). `viz/` depends on everything; nothing depends on it.

---

## 2. SRS — External Interfaces

### 2.1 REPL Commands

```
tabula [sheet.tsv]

set <cell> <literal | =formula>   edit a cell (triggers incremental recompute)
get <cell>                        value + raw content of one cell
show [range]                      render grid (values); formulas shown with :set formulas on
explain <cell>                    full pipeline: tokens, AST, references, opt diff, bytecode, value
deps <cell>                       precedents and dependents (direct + transitive counts)
name <id> <range> | names         define / list named ranges
stats                             last edit: recomputed/total cells, VM instructions, time
:set opt on|off                   toggle optimizer (recompiles all formulas)
load <file> | save <file>         TSV persistence
report <file>.html                write HTML report
quit
```

Exit codes (batch mode `tabula --run script.txt`): 0 success · 1 command/compile error · 3 usage error. Cell-level formula errors are **not** process errors — they become error values in the grid (real-spreadsheet behavior).

### 2.2 Diagnostic and Error-Value Format

Compile-time diagnostic (shown at `set` time; cell still stores the text and displays an error value):

```
error[SyntaxError] in B2: expected ')' after argument list
  =SUM(A1:A9 * 2
             ^
```

| Error value | Produced by |
|---|---|
| `#NAME?`  | unknown function or named range (semantic) |
| `#REF!`   | reference outside grid bounds A–ZZ / 1–10000 (semantic) |
| `#VALUE!` | type error at evaluation (e.g. `"abc" * 2`), or syntax/lexical error stored in cell |
| `#DIV/0!` | division or `MOD` by zero (runtime) |
| `#CYCLE!` | cell participates in a reference cycle (whole-sheet semantic) — message prints the path, e.g. `cycle: B2 → C4 → B2` |

**Propagation rule:** if any evaluated operand of an operator or scalar function argument is an error, the result is that error (first in evaluation order). Exceptions defined per function spec: `COUNT` skips error cells; `ISNUMBER`/`ISBLANK` return `FALSE`/`TRUE` per their semantics; `IF` evaluates only the taken branch (short-circuit).

---

## 3. Language Specification — Lexical Level

A cell's raw text is a **literal** (number / string / boolean / blank) unless it starts with `=`, in which case everything after `=` is a formula tokenized as follows.

### 3.1 Token Classes

| Class | Members / pattern |
|---|---|
| Cell reference | `[$]?[A-Z]{1,2}[$]?[0-9]+` (e.g. `A1`, `$B$2`, `AA10`) |
| Range | `<cellref> ':' <cellref>` (lexed as two REF tokens + COLON; combined by parser) |
| Number | `[0-9]+ ('.' [0-9]+)? | '.' [0-9]+` |
| String | `"` chars with `""` as escaped quote `"` (spreadsheet convention) |
| Boolean | `TRUE` `FALSE` (case-insensitive) |
| Identifier | `[A-Za-z_][A-Za-z0-9_.]*` — function name or named range (resolved in sema) |
| Operators | `+ - * / % ^ &  = <> < <= > >=` |
| Delimiters | `( ) , :` |

Identifiers and function names are case-insensitive (normalized to upper case). Whitespace ignored between tokens. Every token records `(type, lexeme, value, start_col, end_col)` — positions are within the formula text, used for caret diagnostics.

### 3.2 Lexical Errors

Illegal character, unterminated string, malformed number (`1.2.3`), malformed reference (`A0`, row 0 doesn't exist — caught here as reference syntax). Scanner reports and skips to continue; a formula with lexical errors compiles to a chunk that yields `#VALUE!` and the diagnostics are shown at `set` time.

---

## 4. Language Specification — Grammar (EBNF)

```ebnf
formula        = "=" expression EOF ;

expression     = comparison ;
comparison     = concat { ( "=" | "<>" | "<" | "<=" | ">" | ">=" ) concat } ;
concat         = additive { "&" additive } ;
additive       = multiplicative { ( "+" | "-" ) multiplicative } ;
multiplicative = power { ( "*" | "/" | "%" ) power } ;
power          = unary [ "^" power ] ;                (* right-associative *)
unary          = "-" unary | primary ;
primary        = NUMBER | STRING | BOOLEAN
               | range | CELLREF | IDENT             (* named range *)
               | IDENT "(" [ args ] ")"              (* function call *)
               | "(" expression ")" ;
range          = CELLREF ":" CELLREF ;
args           = expression { "," expression } ;
```

Precedence (low→high): comparison < `&` < `+ -` < `* / %` < `^` (right-assoc) < unary `-`. Implemented with Pratt precedence climbing; the table mirrors these tiers.

### 4.1 Type System and Static Semantics

Value types: `Number`, `Text`, `Boolean`, `Blank`, `Error`, and (as an argument only) `Range`.

- **Ranges are not first-class:** a `Range` may appear only as an argument to a range-accepting function (`SUM`, `AVG`, `MIN`, `MAX`, `COUNT`, `COUNTIF`). `=A1:B2 + 1` is a **semantic error** (range in scalar context).
- **Function signatures** (registry-driven): each `FunctionSpec` declares arity (fixed, min–max, or variadic) and parameter kinds (scalar / range / any). Checked statically; violations are diagnostics at `set` time and the cell shows `#VALUE!`.
- **Static type checks** where decidable from literals and operator results (e.g. `=LEN(1 > 2)` — comparison yields Boolean, `LEN` requires Text ⇒ diagnostic). Cell reference types are unknown statically, so most type errors are runtime `#VALUE!` — both layers exist and are individually demonstrable.
- **Coercions at evaluation:** Blank → `0` / `""` in numeric/text context; Boolean → `1/0` in numeric context; Text is **not** implicitly numeric (`="2"+1` ⇒ `#VALUE!`). `&` coerces both sides to Text.
- **Name resolution order** for `IDENT`: function registry (when followed by `(`), else named-range table, else `#NAME?`.
- **Reference validation:** parsed references outside `A..ZZ` × `1..10000` ⇒ `#REF!` diagnostic.
- **Whole-sheet rule:** the precedent relation over all formula cells must be acyclic; violations mark every cell on the cycle `#CYCLE!` (see §6.3).

---

## 5. Detailed Module Design — Micro Layer

### 5.1 Lexer

Single-pass scanner, `pos` cursor over the formula text. Dispatch on current char, maximal munch for `<=` `>=` `<>`. Reference lexing: try `[$]?letters[$]?digits`; validate row ≥ 1; classify REF vs IDENT by the digit tail (`A1` is REF, `A1X` is IDENT). Output `list[Token]` + EOF. O(n).

### 5.2 Parser

Recursive descent with a Pratt loop for the binary tiers (`{TokenType: (lbp, right_assoc?)}`). `^` handled right-associatively (recurse at same binding power). On error: record diagnostic, abort parse of this formula (no multi-error recovery needed — formulas are one expression; the *sheet* recovers because one bad cell never affects others — this per-cell containment is the project's error-recovery story, contrasted with panic mode in the report).

**AST nodes** (dataclasses with `Span`):

```
Number(value)  Text(value)  Bool(value)
Ref(cellref)   Range(start, end)   Name(ident)
Unary(op, operand)   Binary(op, left, right)
Call(fname, args)
```

### 5.3 Semantic Analyzer

Visitor over the AST with access to two symbol tables:

- **Function registry** (`sema/functions.py`): `FunctionSpec(name, min_args, max_args, param_kinds, impl, error_policy)` for the ~20 builtins. Single source of truth used by the checker (arity/kinds), the optimizer (purity — all builtins are pure, enabling folding), and the VM (implementation).
- **Named-range table** (`sema/names.py`): `name → RangeRef|CellRef`, case-insensitive; classic symbol table with declare/resolve/list; redefinition allowed with recompilation of dependent formulas.

Checks per §4.1; every diagnostic carries the formula span. Simultaneously the visitor **extracts the reference set**: all `Ref`/`Range` nodes plus resolutions of `Name` nodes, expanded to a set of `CellRef` precedents (ranges kept symbolic in the AST but expanded for the graph, capped: a range covering > 50,000 cells is a `#REF!` diagnostic).

Output: `CheckedFormula(ast, precedents: set[CellRef], diagnostics)`.

### 5.4 AST Optimizer

Pass manager runs passes to fixpoint (bounded 10 iterations), each pass a pure AST→AST transform returning `(new_ast, changes: list[str])` for the `explain` opt-diff:

| Pass | Transform |
|---|---|
| Constant folding | `Binary/Unary/Call` with all-constant, pure operands ⇒ evaluated `Number/Text/Bool` (evaluation via the same VM applied to a mini-chunk — single semantics, no duplicated arithmetic) |
| Algebraic simplification | `x+0, x-0, x*1, x/1, x^1 → x`; `x*0 → 0` (safe: operands are pure); `x&"" → x`; `--x → x` |
| Branch elimination | `IF(TRUE,a,b) → a`, `IF(FALSE,a,b) → b`; `AND(...FALSE...) → FALSE`, `OR(...TRUE...) → TRUE` when the constant makes the rest irrelevant and remaining args are pure |

Note: folding runs **before** dependency extraction is finalized — `=IF(FALSE, A1, 5)` ends with *no* precedents, which visibly shrinks the dependency graph (demo point: optimization changes recomputation behavior, not just speed).

### 5.5 Bytecode Generator, Peephole, and Chunk Format

```
Chunk: code: list[Instruction], consts: list[Value], refs: list[CellRef|RangeRef]
Instruction = (OpCode, operand?)

OpCode set:
  CONST k                     push consts[k]
  LOAD_CELL r                 push grid value of refs[r]   (Blank if empty)
  LOAD_RANGE r                push RangeView over refs[r]
  ADD SUB MUL DIV MOD POW NEG CONCAT
  EQ NE LT LE GT GE  NOT
  JMP a  JMP_FALSE a          intra-formula jumps (compiled IF/AND/OR short-circuit)
  CALL f_idx argc             invoke FunctionSpec.impl on argc stack values
  RET                         top of stack is the cell's value
```

Lowering is a post-order AST walk; `IF`/`AND`/`OR` compile to jump patterns (short-circuit — the course's boolean-by-jumping concept), not `CALL`s. Peephole pass over the linear code: `NOT; JMP_FALSE → JMP_TRUE`-style fusions and `CONST; NEG → CONST(-v)` residuals the AST passes can't see.

### 5.6 Evaluation VM

`evaluate(chunk, grid) → Value`. Operand stack of `Value`s; dispatch via `match` on OpCode. Arithmetic/comparison implement the coercion and error-propagation rules of §2.2/§4.1: every binary op first checks operands for `ErrorValue` and returns it. `LOAD_CELL` of a cell currently marked `#CYCLE!` or holding any error propagates that error. Runtime errors raised as `Value`s, never Python exceptions: `DIV/MOD` by zero ⇒ `#DIV/0!`; type violations ⇒ `#VALUE!`. Instruction counter maintained for `stats`.

No call frames are needed (formulas can't define functions) — the VM is deliberately simple; the *interesting* runtime is the macro engine.

---

## 6. Detailed Module Design — Macro Layer

### 6.1 Grid and Cells

```
Cell = (raw: str, kind: LITERAL|FORMULA, chunk: Chunk|None,
        value: Value, diags: list[Diagnostic])
Grid = sparse dict {(col:int, row:int): Cell}; bounds A..ZZ × 1..10000
```

TSV persistence: tab-separated raw texts; round-trip property `load(save(g)) == g` is a test invariant.

### 6.2 Dependency Graph

```
DependencyGraph:
  precedents: dict[CellRef, set[CellRef]]     # what this cell reads
  dependents: dict[CellRef, set[CellRef]]     # reverse edges, kept in sync
  update(cell, new_precedents)                # diff-based edge replacement
  find_cycle(start) -> list[CellRef] | None   # iterative DFS with WHITE/GRAY/BLACK coloring
  dirty_closure(seed: set) -> set             # BFS over dependents
  topo_order(dirty: set) -> list[CellRef]     # Kahn's algorithm restricted to the dirty
                                              #   subgraph (in-degrees counted within it)
```

Range precedents are expanded to their member cells at graph-update time. Edits to a cell *inside* a range another formula sums are therefore ordinary dependent edges — no special casing.

### 6.3 Edit Controller — the algorithm behind `set`

```
set(cell, text):
 1. compile text (micro pipeline) → Chunk + precedents (or literal value)
 2. graph.update(cell, precedents)
 3. cycle = graph.find_cycle(cell)
    if cycle: mark every cell on it #CYCLE! (store path), add their dependents
              to the dirty set, skip evaluating cycle members
    else: clear #CYCLE! marks that this edit resolved (re-check former cycle peers)
 4. dirty = graph.dirty_closure({cell})
 5. for c in graph.topo_order(dirty): c.value = vm.evaluate(c.chunk, grid)
 6. record stats: |dirty|, total formula cells, Σ instructions, elapsed time
```

Full recompute (`load`, `:set opt` toggle) is the same with `dirty = all formula cells` — one code path, exercised two ways (simplicity + testability).

### 6.4 Correctness Invariants

1. After any `set`, every formula cell's stored value equals a from-scratch evaluation of the whole sheet (checked in tests: incremental result ≡ full-recompute result).
2. Evaluation order respects dependencies: a cell is evaluated only after all its non-cycle precedents.
3. Cycle members and only cycle members show `#CYCLE!`.
4. Optimizer on/off never changes any cell value (only compile artifacts and recompute sets where folding removed references).

---

## 7. `explain` and the HTML Report

`explain B2` prints, in order: raw text → token table → AST tree (box-drawing) → resolved names & precedent set → optimization diff (per-pass change list, before/after AST) → disassembled bytecode with consts/refs pools → cached value + last-evaluation instruction count.

`report out.html`: self-contained HTML (inline CSS, no external assets) with the rendered grid (error values highlighted), the dependency graph as an adjacency table with per-cell in/out degree, and an `explain` section per formula cell. This is the review-demo centerpiece.

---

## 8. Data Flow Example (traceable end-to-end)

Sheet: `A1=10`, `A2=20`, `B1 = =SUM(A1:A2)*2`, `C1 = =IF(FALSE, B1, 7)`

1. `set B1`: tokens `SUM ( A1 : A2 ) * 2` → AST `Binary(*, Call(SUM,[Range(A1,A2)]), 2)` → checker: SUM arity ok, range kind ok; precedents `{A1,A2}` → no folding applies → bytecode `LOAD_RANGE 0; CALL SUM 1; CONST 2; MUL; RET` → graph edges A1→B1, A2→B1 → evaluate ⇒ `60`.
2. `set C1`: branch elimination rewrites `IF(FALSE,B1,7)` ⇒ `7`; precedents shrink to `∅`; bytecode `CONST 7; RET`. `deps C1` shows no precedents — optimization visibly altered the graph.
3. `set A2 35`: dirty closure `{A2, B1}` (C1 untouched); topo order `[A2, B1]`; B1 ⇒ `90`. `stats`: recomputed 2 of 2 formula cells… then demo on the 10k benchmark sheet where the ratio is dramatic.
4. `set A1 =B1`: `find_cycle` returns `A1 → B1 → A1`; both marked `#CYCLE!` with that path; C1 still `7`.

---

## 9. Error-Handling Strategy (summary)

| Layer | Detection | Containment | User sees |
|---|---|---|---|
| Lexer | bad char, unterminated string, bad number/ref | skip & continue scan | diagnostics at `set`; cell shows `#VALUE!` |
| Parser | unexpected token | abort this formula only | positioned diagnostic + `#VALUE!` |
| Sema | unknown name, arity, kind/type, out-of-bounds ref | poison to error value | diagnostic + `#NAME?`/`#REF!`/`#VALUE!` |
| Sheet sema | reference cycles | cycle members quarantined, rest of sheet evaluates | `#CYCLE!` + printed path |
| Runtime | div/0, type coercion failures | error values propagate through dependents | `#DIV/0!`/`#VALUE!` in affected cells |

The engine process never crashes; a cell's failure never blocks evaluation of unrelated cells.

---

## 10. Testing Strategy

| Level | Contents |
|---|---|
| Unit — refs/values | reference parse/format round-trip incl. `$` forms, bounds; error-value propagation table |
| Unit — lexer | every token type; each lexical error; position accuracy |
| Unit — parser | AST shape per construct; precedence/associativity table-driven (esp. `^` right-assoc, `&` vs `+`); error positions |
| Unit — sema | per-rule positive+negative: arity, kinds, unknown names, bounds; precedent-set extraction incl. named ranges |
| Unit — optimizer | per-pass before/after; fixpoint termination; invariant: opt on/off value-equivalence on corpus |
| Unit — codegen/VM | golden bytecode per construct; short-circuit IF/AND/OR (side-proof: untaken branch's cell errors don't propagate); every function spec; every error value |
| Unit — graph | edge diffing on re-edit; cycle detection (self-loop, 2-cycle, long cycle, cycle via range); dirty closure; topo order validity |
| Scenario | edit scripts asserting values AND exact recompute sets after each step (the incremental contract) |
| Benchmark | generated sheets (chain, tree, wide-fanout, 10k mixed): incremental vs full recompute cell counts and timing; assert NFR-2 |

Boundary cases: empty sheet, formula referencing blank cells, maximum-size range, `ZZ10000`, deep dependency chains (recursion-free iterative algorithms verified ≥ 5,000 deep), redefining a named range recompiles users.

---

## 11. Design Decisions & Trade-offs

| Decision | Alternatives | Rationale |
|---|---|---|
| Stack bytecode as IR | TAC quadruples; direct AST interpretation | Formulas are single expressions — stack IR is the natural fit and course-permitted ("other IR"); AST-walking would skip codegen entirely; TAC adds temp bookkeeping with no analysis payoff here (the *graph* is where dataflow analysis lives) |
| Optimization at AST level + peephole | TAC-level passes | Folding/simplification are expression-shaped; doing them on the AST keeps a visible before/after for `explain` |
| Iterative DFS/Kahn (no recursion) | recursive graph algorithms | Sheets can have 10k-deep chains; Python recursion limits would be an artificial failure mode |
| Errors as values, not exceptions | abort evaluation on first error | Faithful spreadsheet semantics; one broken cell must not break the sheet; richer semantic story for the report |
| Dirty-set + topo per edit | full recompute always; reactive/observer callbacks | The entire point of the project — measurable incrementality; observers hide the scheduling concept |
| Case-insensitive names, `""` string escapes | case-sensitive, backslash escapes | Match spreadsheet-user expectations (demo audiences know Excel) |
| Python, hand-written front end | C/Java; parser generators | Manual-recommended; every line viva-explainable |

## 12. Requirement Traceability

FR-1→ §6.1 · FR-2→ §3, §5.1 · FR-3→ §4, §5.2 · FR-4→ §5.3 · FR-5→ §5.3 · FR-6→ §6.2 · FR-7→ §6.2–6.3 · FR-8→ §5.4–5.5 · FR-9→ §5.5–5.6 · FR-10→ §2.2, §5.6 · FR-11→ §6.3 · FR-12→ §2.1, §7 · FR-13→ §6.3 · FR-14→ §6.1 · FR-15→ §9.
