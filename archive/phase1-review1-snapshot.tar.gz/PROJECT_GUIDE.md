# Project Guide — Tabula

Two things live here: a map of every file, and a slide-by-slide script for the
Review 1 presentation.

---

# Part 1 — What every file does

## Documents you submit

| File | What it is | When you use it |
|---|---|---|
| `Phase1_Review1_Report_Tabula.pdf` | The 29-page Review 1 report: all Phase 1 deliverables (abstract → prototype) plus Appendix A with the complete source listing | Hand in / email before Review 1 |
| `Review1_Tabula_Presentation.pptx` | 19-slide deck for the Review 1 viva | Present at Review 1 |
| `docs_review1_source.html` | The HTML the PDF is generated from | Edit this, then regenerate the PDF (command at the bottom) |

## Planning documents

| File | What it is |
|---|---|
| `requirements.md` | The project from a management view: problem statement, motivation, objectives, scope, 15 functional + 6 non-functional requirements, concept mapping, deliverables per phase |
| `design.md` | The technical specification (SRS): architecture, module decomposition, full language spec (tokens, EBNF grammar, type rules), per-module algorithms, bytecode ISA, testing strategy, design trade-offs |
| `tasks.md` | 38 tasks across the three phases, each with a "done when" criterion, plus a dependency graph and risk register |
| `README.md` | How to install and run; command reference; formula-language tour |
| `PROJECT_GUIDE.md` | This file |

## The implementation — `tabula/`

The pipeline runs top to bottom: each module consumes what the one above produces.

| File | Role | The one thing to remember |
|---|---|---|
| `refs.py` | Cell and range references | Parses `A1`, `$B$2`, `AA10`; converts column letters to indices; enforces the A–ZZ × 1–10000 grid bounds |
| `values.py` | The value model | Five types (Number, Text, Boolean, Blank, Error) and the coercion rules — this is where "text is never implicitly numeric" is enforced |
| `lexer.py` | **Lexical analysis** | Hand-written scanner: turns `=SUM(A1:A3)*2` into a token stream, each token tagged with its column so errors can point at it |
| `parser.py` | **Syntax analysis** | Recursive descent with a Pratt loop for expressions; builds the AST. The binding-power table encodes all seven precedence tiers |
| `evaluator.py` | Evaluation (**interim**) | Walks the AST and computes values; propagates error values; detects cycles via an active-cell set. Phase 3 replaces this with the bytecode VM |
| `engine.py` | Grid + edit controller | Holds the cells, decides literal vs formula, compiles on `set`, formats the caret diagnostics, renders the grid, implements `explain` |
| `cli.py` | The REPL | Command parsing and dispatch; interactive mode and batch (script) mode |

## Tests — `tests/`

| File | Covers |
|---|---|
| `test_lexer.py` | 15 tests: every token class, number forms, doubled-quote escapes, maximal munch, reference-vs-identifier classification, positions, three lexical errors |
| `test_parser.py` | 14 tests: precedence/associativity table, ranges, calls, nesting, syntax errors asserted by message **and** column |
| `test_evaluator.py` | 20 tests: semantics, coercions, aggregates, lazy `IF`, all error values, cycles, per-cell containment |
| `test_gradebook.py` | 5 tests: the whole gradebook sheet checked against independently computed arithmetic |

Run everything: `python3 -m pytest tests/ -q` → **54 passed**

## Samples — `examples/` and `tools/`

| File | Purpose |
|---|---|
| `examples/demo.txt` | The Review 1 demo script: builds a sheet, edits an input, shows `explain`, then triggers a syntax error, a `#DIV/0!` and a cycle |
| `examples/gradebook.txt` | A realistic 62-cell gradebook (22 formulas) as a Tabula script |
| `examples/gradebook.xlsx` | **The same sheet as a real Excel workbook** — open it in Excel and every value must match Tabula's output |
| `tools/make_gradebook.py` | Generates both gradebook files from one definition so they cannot drift (uses openpyxl — a dev-only tool, not part of Tabula) |

### Why the Excel file matters

It is an **oracle**. Excel computes the same 22 formulas independently; if Tabula
disagrees with Excel on any cell, Tabula is wrong. That is much stronger evidence
than a test that merely repeats your own arithmetic.

Two deliberate dialect differences, worth knowing before someone asks:

- **`AVG` vs `AVERAGE`** — Tabula uses `AVG` (per the language spec in `design.md`);
  Excel spells it `AVERAGE`. The generator translates when writing the workbook.
- **`%`** — in Tabula it is infix modulo (`=12%4` → 0); in Excel `%` is a postfix
  percent operator and Excel's modulo is `MOD(a,b)`.

Neither is a bug: Tabula is its own language, not an Excel clone. But say so
plainly if asked — it shows you know where your design departs from the model.

---

# Part 2 — How to present the deck

**Shape of it:** 19 slides, about 10–12 minutes, then viva. Slides 1–8 are the
case for the project; 9–14 are the design; 15–17 are proof it works; 18–19 close.
The examiners' marks sit mostly in slides 3, 5, 8, 9 and 15–17 — spend your time
there and move briskly through the rest.

**The sentence to open with, and keep returning to:**
> "Every cell formula is a small program, so a spreadsheet is really thousands of
> tiny programs plus a dependency graph — and building it properly needs a whole
> compiler."

### Slide-by-slide

| # | Slide | What to say (keep it to this) |
|---|---|---|
| 1 | Title | Name the project in one line: a spreadsheet engine where each formula goes through a full compiler pipeline. Don't read the title aloud. |
| 2 | Agenda | Five seconds. "Problem, design, prototype, roadmap." Move on. |
| 3 | Problem Statement | **Marks slide.** Make the two-layer split explicit: per-formula compilation, and per-sheet dependency analysis. Land the closing line: recomputing all N cells per edit is what makes a naive engine unusable. |
| 4 | Motivation | Why it's the right topic *for this course*: every classical phase is exercised, plus concepts a normal project never reaches. |
| 5 | Objectives | **Marks slide.** Don't read all ten. Say "front end, analysis, back end" and give one example from each column. |
| 6 | Scope | Point at the out-of-scope line deliberately — it shows you set boundaries rather than over-promised. |
| 7 | Background Study | Name your sources out loud: the Dragon Book, Pratt 1973, Sestoft on spreadsheet internals, Kahn 1962. Then the table: what each existing system leaves undone. |
| 8 | Compiler Concepts | **Highest-value slide.** Walk the left column top to bottom — this is the examiner's checklist that your project covers the syllabus. Pause on "cycle detection as a whole-program semantic check." |
| 9 | System Architecture | **Marks slide.** Trace one path with your finger: edit a cell → compile it → update the graph → check for cycles → schedule → evaluate. Then the dependency rule at the bottom. |
| 10 | Micro Layer | Follow `=SUM(A1:A3)*2` down the left column. Then the grey box: optimization removes the dependency on `B1`, so the optimizer changes the *graph*, not just the speed. That line is your innovation argument. |
| 11 | Macro Layer | Six steps, said quickly. Be explicit that the "1 edit → 14 cells" figure is a **Phase 3 target**, not a measurement — say the word "target". |
| 12 | Language Specification | Point to `power = unary [ "^" power ]` and say: that one recursive rule makes `^` right-associative, so `=2^3^2` is 512, not 64. It is the most concrete parsing fact you own. |
| 13 | Error Model | The idea in one sentence: errors are *values* that flow through formulas, not crashes. Hence one broken cell never takes the sheet down. |
| 14 | Innovation | Five claims, ten seconds each. Lead with incremental recomputation. |
| 15 | Prototype | Switch tone: "this is running today." 1,041 lines, seven modules, standard library only. Be upfront that the evaluator is interim and the VM replaces it in Phase 3. |
| 16 | Demonstration | **Do this live if you can** (`python3 -m tabula.cli examples/demo.txt`), with the slide as fallback. Narrate three beats: the edit propagates; the syntax error is located by caret; the cycle is caught — and everything else still evaluates. |
| 17 | Testing | 54 tests, 0.02 s. Call out two: `=2^3^2` proves associativity, and the untaken `1/0` branch proves `IF` is lazy. Mention the gradebook is cross-checked against a real Excel file. |
| 18 | Roadmap | Phase 1 done, Phase 2 analysis, Phase 3 optimizer and VM. Ten seconds. |
| 19 | Close | Restate the one-line pitch and stop talking. Let them ask. |

### Live-demo order (if you run it)

```
python3 -m pytest tests/ -q                     # 54 passed
python3 -m tabula.cli examples/gradebook.txt    # the realistic sheet
python3 -m tabula.cli examples/demo.txt         # errors and the cycle
```
Then open `examples/gradebook.xlsx` in Excel beside it and point out the numbers
match.

### Questions you should expect

| Question | Your answer |
|---|---|
| Why not use Lex/Yacc or ANTLR? | Hand-writing it means every algorithm is mine to explain, and I control the error messages — positions and carets came free. |
| How does Pratt parsing work? | Each operator has a binding power; the loop keeps consuming while the next operator binds tighter. Right-associativity is one flag: recurse at the same power instead of one higher. |
| How do you detect cycles? | Depth-first search with three-colouring — an edge back to a grey (in-progress) node is a cycle. In the prototype it's an active-cell set; Phase 2 makes it a proper graph walk that also reports the path. |
| Where is the intermediate code? | Phase 3: a stack bytecode with constant and reference pools. A formula is a single expression, so stack IR fits it better than three-address code. |
| What is actually optimized? | Constant folding, algebraic simplification, branch elimination, and a bytecode peephole — plus the big one, recomputing only dirty cells. |
| Isn't this just Excel? | Excel is the *problem statement*. The project is the machinery underneath, which Excel hides. |
| **What happens with a very deep chain?** | Be honest: the prototype evaluator recurses, so past 200 cells it hits Python's stack limit. `design.md` §11 already requires iterative DFS and Kahn for exactly this reason; Phase 2 fixes it. |

That last one is a known, documented limitation — say it before they find it.

---

# Regenerating things

```bash
python3 tools/make_gradebook.py     # rebuild both gradebook files
python3 -m pytest tests/ -q         # run all tests

# rebuild the PDF after editing docs_review1_source.html
"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" --headless \
  --disable-gpu --no-pdf-header-footer \
  --print-to-pdf="Phase1_Review1_Report_Tabula.pdf" docs_review1_source.html
```
