# Tabula

A spreadsheet engine whose formulas are compiled: every cell formula passes through a
hand-written compiler pipeline (lexer → parser → semantic analyser → optimiser → bytecode
→ VM), and the sheet as a whole is analysed for dependencies, circular references, and
minimal recomputation.

BCSE307P Compiler Design Laboratory — individual project.
See `requirements.md` (project definition), `design.md` (architecture and SRS), and
`tasks.md` (phase-wise plan).

## Status — Phase 1 (prototype)

Implemented so far: reference/value model, formula lexer, Pratt parser, direct AST
evaluator over a grid, and a REPL with `explain`. The bytecode VM, dependency graph,
optimiser, and incremental recomputation arrive in Phases 2–3.

## Requirements

Python 3.11+ (standard library only). `pytest` for the test suite.

## Running

```
python3 -m tabula.cli                  # interactive REPL
python3 -m tabula.cli examples/demo.txt # batch mode: echoes each command
python3 -m pytest tests/ -q             # test suite (49 tests)
```

## Commands

| Command | Effect |
|---|---|
| `set <cell> <literal>` | store a number, text, or `TRUE`/`FALSE` |
| `set <cell> =<formula>` | compile and store a formula |
| `get <cell>` | value plus the raw formula text |
| `show` | render the grid |
| `explain <cell>` | tokens, token classes, AST tree, and value |
| `help`, `quit` | — |

## Formula language (Phase 1 subset)

- **Literals** — `12`, `3.5`, `.5`, `"text"` (with `""` as an escaped quote), `TRUE`/`FALSE`
- **References** — `A1`, `$B$2`, ranges `A1:B4`; bounds A–ZZ × 1–10000
- **Operators** — `+ - * / % ^` arithmetic, `&` concatenation, `= <> < <= > >=` comparison,
  unary `-`. Precedence (loosest to tightest): comparison, `&`, `+ -`, `* / %`, `^`
  (right-associative), unary minus.
- **Functions** — `SUM AVG MIN MAX COUNT IF ABS ROUND LEN`
  (the full ≈20-function library lands in Phase 2)
- **Error values** — `#DIV/0!`, `#VALUE!`, `#NAME?`, `#CYCLE!`; errors are values that
  propagate through dependent formulas, and a malformed formula never affects other cells.

## Example

```
tabula> set A1 10
tabula> set A2 25
tabula> set B1 =SUM(A1:A2)*2
tabula> get B1
B1 = 70   (=SUM(A1:A2)*2)
tabula> set A2 35
tabula> get B1
B1 = 90   (=SUM(A1:A2)*2)
```

## Layout

```
tabula/refs.py        cell/range references, bounds
tabula/values.py      value model and error values
tabula/lexer.py       hand-written scanner
tabula/parser.py      Pratt parser, AST, tree printer
tabula/evaluator.py   direct AST evaluation (interim; VM replaces it in Phase 3)
tabula/engine.py      grid, edit controller, diagnostics, explain
tabula/cli.py         REPL
tests/                lexer, parser, evaluator tests
examples/demo.txt     demonstration script
```
