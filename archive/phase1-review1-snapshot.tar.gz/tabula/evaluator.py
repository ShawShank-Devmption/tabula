"""Phase 1 prototype: direct AST evaluation over the grid.

Interim component — replaced by the bytecode VM in Phase 3. On-demand
recursive evaluation with an active-cell set for dynamic cycle detection
(Phase 2 replaces this with the dependency graph + topological order).
"""
from __future__ import annotations

from . import parser as P
from .refs import CellRef
from .values import (BLANK, CYCLE_ERR, DIV0, NAME_ERR, VALUE_ERR,
                     ErrorValue, is_error, to_number, to_text)


def _num_args(values):
    """Coerce operands for arithmetic; first error wins."""
    out = []
    for v in values:
        n = to_number(v)
        if is_error(n):
            return n
        out.append(n)
    return out


class Evaluator:
    def __init__(self, grid):
        self.grid = grid            # provides raw_cell(ref) -> (kind, ast_or_value)
        self.active: set = set()    # cells currently being evaluated (cycle check)

    # -- cell protocol ---------------------------------------------------
    def value_of(self, ref: CellRef):
        key = ref.key()
        if key in self.active:
            return CYCLE_ERR
        cell = self.grid.cells.get(key)
        if cell is None:
            return BLANK
        if cell.kind == "literal":
            return cell.payload
        if cell.kind == "broken":       # formula that failed to compile
            return VALUE_ERR
        self.active.add(key)
        try:
            return self.eval(cell.payload)
        finally:
            self.active.discard(key)

    # -- expression evaluation --------------------------------------------
    def eval(self, node):
        method = getattr(self, f"_eval_{type(node).__name__.lower()}")
        return method(node)

    def _eval_number(self, n): return n.value
    def _eval_text(self, n): return n.value
    def _eval_bool(self, n): return n.value
    def _eval_ref(self, n): return self.value_of(n.ref)

    def _eval_rangenode(self, n):
        # A bare range outside a function argument is a semantic error.
        return VALUE_ERR

    def _eval_name(self, n):
        return NAME_ERR  # named ranges arrive in Phase 2

    def _eval_unary(self, n):
        v = to_number(self.eval(n.operand))
        return v if is_error(v) else -v

    def _eval_binary(self, n):
        left = self.eval(n.left)
        if is_error(left):
            return left
        right = self.eval(n.right)
        if is_error(right):
            return right
        op = n.op
        if op == "&":
            lt, rt = to_text(left), to_text(right)
            return lt if is_error(lt) else rt if is_error(rt) else lt + rt
        if op in ("=", "<>"):
            eq = left == right
            return eq if op == "=" else not eq
        if op in ("<", "<=", ">", ">="):
            if isinstance(left, str) and isinstance(right, str):
                a, b = left, right
            else:
                nums = _num_args([left, right])
                if is_error(nums):
                    return nums
                a, b = nums
            return {"<": a < b, "<=": a <= b, ">": a > b, ">=": a >= b}[op]
        nums = _num_args([left, right])
        if is_error(nums):
            return nums
        a, b = nums
        if op == "+": return a + b
        if op == "-": return a - b
        if op == "*": return a * b
        if op == "/": return DIV0 if b == 0 else a / b
        if op == "%": return DIV0 if b == 0 else a % b
        if op == "^": return a ** b
        return VALUE_ERR

    # -- functions ---------------------------------------------------------
    def _flatten(self, arg_nodes):
        """Evaluate args, expanding ranges to their non-blank cell values."""
        vals = []
        for node in arg_nodes:
            if isinstance(node, P.RangeNode):
                for ref in node.rng.cells():
                    v = self.value_of(ref)
                    if v is not BLANK:
                        vals.append(v)
            else:
                vals.append(self.eval(node))
        return vals

    def _eval_call(self, n):
        fname = n.fname
        if fname == "IF":
            if len(n.args) != 3:
                return VALUE_ERR
            cond = self.eval(n.args[0])
            if is_error(cond):
                return cond
            return self.eval(n.args[1] if cond else n.args[2])  # lazy branch
        if fname in ("SUM", "AVG", "MIN", "MAX", "COUNT"):
            vals = self._flatten(n.args)
            if fname == "COUNT":  # counts numeric entries only
                numeric = [v for v in vals
                           if isinstance(v, (int, float)) and not isinstance(v, bool)]
                return float(len(numeric))
            nums = _num_args(vals)
            if is_error(nums):
                return nums
            if not nums:
                return DIV0 if fname == "AVG" else 0.0
            if fname == "SUM": return float(sum(nums))
            if fname == "AVG": return sum(nums) / len(nums)
            if fname == "MIN": return float(min(nums))
            if fname == "MAX": return float(max(nums))
        if fname == "ABS":
            v = to_number(self.eval(n.args[0])) if len(n.args) == 1 else VALUE_ERR
            return v if is_error(v) else abs(v)
        if fname == "ROUND":
            if len(n.args) not in (1, 2):
                return VALUE_ERR
            v = to_number(self.eval(n.args[0]))
            d = to_number(self.eval(n.args[1])) if len(n.args) == 2 else 0
            if is_error(v): return v
            if is_error(d): return d
            return float(round(v, int(d)))
        if fname == "LEN":
            t = to_text(self.eval(n.args[0])) if len(n.args) == 1 else VALUE_ERR
            return t if is_error(t) else float(len(t))
        return ErrorValue("#NAME?", f"unknown function {fname}")
