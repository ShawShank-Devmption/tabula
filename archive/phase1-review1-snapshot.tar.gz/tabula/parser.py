"""Recursive-descent parser with Pratt precedence climbing for expressions.

Grammar (design.md section 4): seven precedence tiers, comparison lowest,
'^' right-associative, unary minus binding tighter than '^' operand position.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from .lexer import Token, TokType, tokenize, LexError
from .refs import CellRef, RangeRef


# ---------- AST ----------
@dataclass
class Number:
    value: float


@dataclass
class Text:
    value: str


@dataclass
class Bool:
    value: bool


@dataclass
class Ref:
    ref: CellRef


@dataclass
class RangeNode:
    rng: RangeRef


@dataclass
class Name:
    ident: str


@dataclass
class Unary:
    op: str
    operand: object


@dataclass
class Binary:
    op: str
    left: object
    right: object


@dataclass
class Call:
    fname: str
    args: list = field(default_factory=list)


class ParseError(Exception):
    def __init__(self, message: str, pos: int):
        super().__init__(message)
        self.message, self.pos = message, pos


# binding powers: (left_bp, right_associative)
_BINARY_BP = {
    TokType.EQ: (10, False), TokType.NE: (10, False),
    TokType.LT: (10, False), TokType.LE: (10, False),
    TokType.GT: (10, False), TokType.GE: (10, False),
    TokType.AMP: (20, False),
    TokType.PLUS: (30, False), TokType.MINUS: (30, False),
    TokType.STAR: (40, False), TokType.SLASH: (40, False),
    TokType.PERCENT: (40, False),
    TokType.CARET: (50, True),
}


class Parser:
    def __init__(self, tokens: list[Token]):
        self.toks = tokens
        self.i = 0

    def peek(self) -> Token:
        return self.toks[self.i]

    def advance(self) -> Token:
        tok = self.toks[self.i]
        self.i += 1
        return tok

    def expect(self, ttype: TokType, what: str) -> Token:
        if self.peek().type is ttype:
            return self.advance()
        raise ParseError(f"expected {what}", self.peek().pos)

    # -- Pratt loop -----------------------------------------------------
    def parse_expression(self, min_bp: int = 0):
        left = self.parse_unary()
        while True:
            tok = self.peek()
            bp = _BINARY_BP.get(tok.type)
            if bp is None or bp[0] < min_bp:
                return left
            self.advance()
            lbp, right_assoc = bp
            next_min = lbp if right_assoc else lbp + 1
            right = self.parse_expression(next_min)
            left = Binary(tok.lexeme, left, right)

    def parse_unary(self):
        if self.peek().type is TokType.MINUS:
            tok = self.advance()
            return Unary("-", self.parse_unary())
        return self.parse_primary()

    def parse_primary(self):
        tok = self.advance()
        if tok.type is TokType.NUMBER:
            return Number(tok.value)
        if tok.type is TokType.STRING:
            return Text(tok.value)
        if tok.type is TokType.BOOL:
            return Bool(tok.value)
        if tok.type is TokType.CELLREF:
            if self.peek().type is TokType.COLON:  # range A1:B4
                self.advance()
                end = self.expect(TokType.CELLREF, "cell reference after ':'")
                return RangeNode(RangeRef(tok.value, end.value))
            return Ref(tok.value)
        if tok.type is TokType.IDENT:
            if self.peek().type is TokType.LPAREN:  # function call
                self.advance()
                args = []
                if self.peek().type is not TokType.RPAREN:
                    args.append(self.parse_expression())
                    while self.peek().type is TokType.COMMA:
                        self.advance()
                        args.append(self.parse_expression())
                self.expect(TokType.RPAREN, "')' after argument list")
                return Call(tok.value, args)
            return Name(tok.value)
        if tok.type is TokType.LPAREN:
            inner = self.parse_expression()
            self.expect(TokType.RPAREN, "')'")
            return inner
        what = f"unexpected {tok.lexeme!r}" if tok.lexeme else "unexpected end of formula"
        raise ParseError(what, tok.pos)


def parse_formula(text: str):
    """Parse formula body (text after '='). Raises LexError/ParseError."""
    tokens = tokenize(text)
    parser = Parser(tokens)
    ast = parser.parse_expression()
    trailing = parser.peek()
    if trailing.type is not TokType.EOF:
        raise ParseError(f"unexpected {trailing.lexeme!r} after expression", trailing.pos)
    return ast


# ---------- AST pretty-printer (explain v0) ----------
def dump_ast(node, prefix: str = "", is_last: bool = True,
             is_root: bool = True) -> list[str]:
    label = {
        Number: lambda n: f"Number({values_fmt(n.value)})",
        Text: lambda n: f'Text("{n.value}")',
        Bool: lambda n: f"Bool({n.value})",
        Ref: lambda n: f"Ref({n.ref})",
        RangeNode: lambda n: f"Range({n.rng})",
        Name: lambda n: f"Name({n.ident})",
        Unary: lambda n: f"Unary({n.op})",
        Binary: lambda n: f"Binary({n.op})",
        Call: lambda n: f"Call({n.fname})",
    }[type(node)](node)
    connector = "" if is_root else ("└── " if is_last else "├── ")
    lines = [prefix + connector + label]
    children = []
    if isinstance(node, Unary):
        children = [node.operand]
    elif isinstance(node, Binary):
        children = [node.left, node.right]
    elif isinstance(node, Call):
        children = node.args
    child_prefix = prefix + ("" if is_root else ("    " if is_last else "│   "))
    for k, child in enumerate(children):
        last = k == len(children) - 1
        lines.extend(dump_ast(child, child_prefix, last, is_root=False))
    return lines


def values_fmt(v: float) -> str:
    return str(int(v)) if v == int(v) else str(v)
