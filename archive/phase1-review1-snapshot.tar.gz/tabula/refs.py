"""Cell and range references: parsing, formatting, bounds (A-ZZ x 1-10000)."""
from __future__ import annotations

import re
from dataclasses import dataclass

MAX_ROW = 10_000
MAX_COL = 26 + 26 * 26  # A..Z, AA..ZZ

_REF_RE = re.compile(r"^(\$?)([A-Z]{1,2})(\$?)([0-9]+)$")


def col_to_index(letters: str) -> int:
    """'A' -> 1, 'Z' -> 26, 'AA' -> 27, 'ZZ' -> 702."""
    n = 0
    for ch in letters:
        n = n * 26 + (ord(ch) - ord("A") + 1)
    return n


def index_to_col(n: int) -> str:
    letters = ""
    while n > 0:
        n, rem = divmod(n - 1, 26)
        letters = chr(ord("A") + rem) + letters
    return letters


@dataclass(frozen=True)
class CellRef:
    col: int  # 1-based
    row: int  # 1-based
    abs_col: bool = False
    abs_row: bool = False

    @staticmethod
    def parse(text: str) -> "CellRef | None":
        m = _REF_RE.match(text.upper())
        if not m:
            return None
        dc, letters, dr, digits = m.groups()
        col, row = col_to_index(letters), int(digits)
        if row < 1 or row > MAX_ROW or col > MAX_COL:
            return None
        return CellRef(col, row, abs_col=dc == "$", abs_row=dr == "$")

    def key(self) -> tuple[int, int]:
        return (self.col, self.row)

    def __str__(self) -> str:
        return (
            ("$" if self.abs_col else "") + index_to_col(self.col)
            + ("$" if self.abs_row else "") + str(self.row)
        )


@dataclass(frozen=True)
class RangeRef:
    start: CellRef
    end: CellRef

    def cells(self):
        c1, c2 = sorted((self.start.col, self.end.col))
        r1, r2 = sorted((self.start.row, self.end.row))
        for col in range(c1, c2 + 1):
            for row in range(r1, r2 + 1):
                yield CellRef(col, row)

    def __str__(self) -> str:
        return f"{self.start}:{self.end}"
