"""Value model: numbers, text, booleans, blanks, and spreadsheet error values."""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ErrorValue:
    code: str  # '#DIV/0!', '#VALUE!', '#REF!', '#NAME?', '#CYCLE!'
    detail: str = ""

    def __str__(self) -> str:
        return self.code


DIV0 = ErrorValue("#DIV/0!")
VALUE_ERR = ErrorValue("#VALUE!")
REF_ERR = ErrorValue("#REF!")
NAME_ERR = ErrorValue("#NAME?")
CYCLE_ERR = ErrorValue("#CYCLE!")

BLANK = None  # an empty cell reads as Blank


def is_error(v) -> bool:
    return isinstance(v, ErrorValue)


def to_number(v):
    """Coerce a value to a number per Tabula rules; ErrorValue on failure.

    Blank -> 0, Boolean -> 1/0, Text is never implicitly numeric.
    """
    if is_error(v):
        return v
    if v is BLANK:
        return 0
    if isinstance(v, bool):
        return 1 if v else 0
    if isinstance(v, (int, float)):
        return v
    return VALUE_ERR


def to_text(v) -> str | ErrorValue:
    if is_error(v):
        return v
    if v is BLANK:
        return ""
    if isinstance(v, bool):
        return "TRUE" if v else "FALSE"
    if isinstance(v, float):
        if v == int(v):
            return str(int(v))
        # Spreadsheet-style display: significant digits, no float artefacts.
        return f"{v:.10g}"
    return str(v)


def display(v) -> str:
    """Human-readable form for the grid renderer."""
    if v is BLANK:
        return ""
    if is_error(v):
        return v.code
    return to_text(v)
