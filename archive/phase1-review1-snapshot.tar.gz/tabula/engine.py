"""Phase 1 grid + edit controller: set/get/show with full recomputation."""
from __future__ import annotations

from dataclasses import dataclass

from .evaluator import Evaluator
from .lexer import LexError, tokenize
from .parser import ParseError, dump_ast, parse_formula
from .refs import CellRef, index_to_col
from .values import BLANK, display


@dataclass
class Cell:
    raw: str
    kind: str        # 'literal' | 'formula' | 'broken'
    payload: object  # value for literal, AST for formula, None for broken


def caret_diagnostic(cellname: str, category: str, message: str,
                     formula: str, pos: int) -> str:
    # pos is within the formula body; +1 accounts for the leading '='
    return (
        f"error[{category}] in {cellname}: {message}\n"
        f"  ={formula}\n"
        f"  {' ' * (pos + 1)}^"
    )


class Sheet:
    def __init__(self):
        self.cells: dict[tuple[int, int], Cell] = {}
        self.evaluator = Evaluator(self)

    # -- editing -----------------------------------------------------------
    def set(self, refname: str, raw: str) -> str | None:
        """Set a cell. Returns a diagnostic string on compile error, else None."""
        ref = CellRef.parse(refname)
        if ref is None:
            return f"error[RefError]: invalid cell reference '{refname}'"
        raw = raw.strip()
        if raw.startswith("="):
            body = raw[1:]
            try:
                ast = parse_formula(body)
                self.cells[ref.key()] = Cell(raw, "formula", ast)
                return None
            except LexError as e:
                self.cells[ref.key()] = Cell(raw, "broken", None)
                return caret_diagnostic(str(ref), "LexicalError",
                                        e.message, body, e.pos)
            except ParseError as e:
                self.cells[ref.key()] = Cell(raw, "broken", None)
                return caret_diagnostic(str(ref), "SyntaxError", e.message, body, e.pos)
        self.cells[ref.key()] = Cell(raw, "literal", _parse_literal(raw))
        return None

    def value(self, refname: str):
        ref = CellRef.parse(refname)
        return self.evaluator.value_of(ref) if ref else None

    # -- rendering -----------------------------------------------------------
    def show(self) -> str:
        if not self.cells:
            return "(empty sheet)"
        cols = sorted({c for c, _ in self.cells})
        rows = sorted({r for _, r in self.cells})
        widths = {}
        table = {}
        for c in cols:
            col_cells = [display(self.evaluator.value_of(CellRef(c, r))) for r in rows]
            for r, text in zip(rows, col_cells):
                table[(c, r)] = text
            widths[c] = max([len(index_to_col(c))] + [len(t) for t in col_cells]) + 2
        head = "     " + "".join(index_to_col(c).ljust(widths[c]) for c in cols)
        lines = [head]
        for r in rows:
            row = f"{r:<5}" + "".join(table[(c, r)].ljust(widths[c]) for c in cols)
            lines.append(row.rstrip())
        return "\n".join(lines)

    def explain(self, refname: str) -> str:
        ref = CellRef.parse(refname)
        cell = self.cells.get(ref.key()) if ref else None
        if cell is None:
            return f"{refname}: (blank)"
        out = [f"cell   : {ref}", f"raw    : {cell.raw}", f"kind   : {cell.kind}"]
        if cell.kind == "formula":
            toks = tokenize(cell.raw[1:])
            out.append("tokens : " + " ".join(
                f"{t.lexeme}" for t in toks if t.lexeme))
            out.append("types  : " + " ".join(
                t.type.name for t in toks if t.lexeme))
            out.append("ast    :")
            out.extend("  " + line for line in dump_ast(cell.payload))
        out.append(f"value  : {display(self.evaluator.value_of(ref))}")
        return "\n".join(out)


def _parse_literal(raw: str):
    if raw == "":
        return BLANK
    if raw.upper() in ("TRUE", "FALSE"):
        return raw.upper() == "TRUE"
    try:
        return float(raw)
    except ValueError:
        return raw  # text literal
