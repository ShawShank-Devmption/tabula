"""Tabula Phase 1 REPL.

Usage:  python -m tabula.cli            interactive
        python -m tabula.cli script.txt batch (echoes commands, for demos)
"""
from __future__ import annotations

import sys

from .engine import Sheet

HELP = """commands:
  set <cell> <literal | =formula>   edit a cell
  get <cell>                        value + raw content
  show                              render the grid
  explain <cell>                    tokens, AST, value for a cell
  help | quit"""


def run_command(sheet: Sheet, line: str) -> str | None:
    parts = line.strip().split(None, 2)
    if not parts:
        return None
    cmd = parts[0].lower()
    if cmd == "quit":
        return "QUIT"
    if cmd == "help":
        return HELP
    if cmd == "set" and len(parts) == 3:
        return sheet.set(parts[1], parts[2])
    if cmd == "get" and len(parts) >= 2:
        ref = parts[1]
        cell = None
        from .refs import CellRef
        r = CellRef.parse(ref)
        if r:
            cell = sheet.cells.get(r.key())
        from .values import display
        raw = f"   ({cell.raw})" if cell and cell.kind != "literal" else ""
        return f"{ref.upper()} = {display(sheet.value(ref))}{raw}"
    if cmd == "show":
        return sheet.show()
    if cmd == "explain" and len(parts) >= 2:
        return sheet.explain(parts[1])
    return f"unrecognized command: {line.strip()!r} (try 'help')"


def main() -> None:
    sheet = Sheet()
    if len(sys.argv) > 1:  # batch mode: echo each command, then its output
        with open(sys.argv[1]) as f:
            for line in f:
                line = line.rstrip("\n")
                if not line.strip() or line.lstrip().startswith("#"):
                    continue
                print(f"tabula> {line}")
                out = run_command(sheet, line)
                if out == "QUIT":
                    break
                if out:
                    print(out)
        return
    print("Tabula prototype - type 'help' for commands")
    while True:
        try:
            line = input("tabula> ")
        except EOFError:
            break
        out = run_command(sheet, line)
        if out == "QUIT":
            break
        if out:
            print(out)


if __name__ == "__main__":
    main()
