"""Hand-written scanner for Tabula formulas.

Tokenizes the text after the leading '='. Every token carries its start
column within the formula text so diagnostics can point at the exact spot.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto

from .refs import CellRef


class TokType(Enum):
    NUMBER = auto()
    STRING = auto()
    BOOL = auto()
    CELLREF = auto()
    IDENT = auto()
    PLUS = auto(); MINUS = auto(); STAR = auto(); SLASH = auto()
    PERCENT = auto(); CARET = auto(); AMP = auto()
    EQ = auto(); NE = auto(); LT = auto(); LE = auto(); GT = auto(); GE = auto()
    LPAREN = auto(); RPAREN = auto(); COMMA = auto(); COLON = auto()
    EOF = auto()


@dataclass
class Token:
    type: TokType
    lexeme: str
    value: object  # parsed literal / CellRef where applicable
    pos: int       # 0-based start column in the formula text


class LexError(Exception):
    def __init__(self, message: str, pos: int):
        super().__init__(message)
        self.message, self.pos = message, pos


_SINGLE = {
    "+": TokType.PLUS, "-": TokType.MINUS, "*": TokType.STAR,
    "/": TokType.SLASH, "%": TokType.PERCENT, "^": TokType.CARET,
    "&": TokType.AMP, "=": TokType.EQ, "(": TokType.LPAREN,
    ")": TokType.RPAREN, ",": TokType.COMMA, ":": TokType.COLON,
}


def tokenize(text: str) -> list[Token]:
    toks: list[Token] = []
    i, n = 0, len(text)
    while i < n:
        ch = text[i]
        if ch.isspace():
            i += 1
            continue
        # -- numbers: 12, 3.5, .5  (maximal munch)
        if ch.isdigit() or (ch == "." and i + 1 < n and text[i + 1].isdigit()):
            start = i
            while i < n and text[i].isdigit():
                i += 1
            if i < n and text[i] == ".":
                i += 1
                while i < n and text[i].isdigit():
                    i += 1
            lexeme = text[start:i]
            toks.append(Token(TokType.NUMBER, lexeme, float(lexeme), start))
            continue
        # -- strings: "..." with "" as the escaped quote
        if ch == '"':
            start, i, parts = i, i + 1, []
            while True:
                if i >= n:
                    raise LexError("unterminated string literal", start)
                if text[i] == '"':
                    if i + 1 < n and text[i + 1] == '"':  # escaped quote
                        parts.append('"')
                        i += 2
                        continue
                    i += 1
                    break
                parts.append(text[i])
                i += 1
            toks.append(Token(TokType.STRING, text[start:i], "".join(parts), start))
            continue
        # -- references, booleans, identifiers
        if ch.isalpha() or ch in "_$":
            start = i
            while i < n and (text[i].isalnum() or text[i] in "_$."):
                i += 1
            word = text[start:i]
            ref = CellRef.parse(word)
            upper = word.upper()
            if ref is not None:
                toks.append(Token(TokType.CELLREF, word, ref, start))
            elif upper in ("TRUE", "FALSE"):
                toks.append(Token(TokType.BOOL, word, upper == "TRUE", start))
            elif "$" in word:
                raise LexError(f"malformed cell reference '{word}'", start)
            else:
                toks.append(Token(TokType.IDENT, word, upper, start))
            continue
        # -- two-char operators before one-char (maximal munch)
        two = text[i:i + 2]
        if two == "<>":
            toks.append(Token(TokType.NE, two, None, i)); i += 2; continue
        if two == "<=":
            toks.append(Token(TokType.LE, two, None, i)); i += 2; continue
        if two == ">=":
            toks.append(Token(TokType.GE, two, None, i)); i += 2; continue
        if ch == "<":
            toks.append(Token(TokType.LT, ch, None, i)); i += 1; continue
        if ch == ">":
            toks.append(Token(TokType.GT, ch, None, i)); i += 1; continue
        if ch in _SINGLE:
            toks.append(Token(_SINGLE[ch], ch, None, i)); i += 1; continue
        raise LexError(f"illegal character {ch!r}", i)
    toks.append(Token(TokType.EOF, "", None, n))
    return toks
